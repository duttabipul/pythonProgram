from django.shortcuts import render
from employee.forms import EmployeeForm
from employee.models import Employee


# Create your views here.
def createEmployee(request):
    if request.method == "POST":
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/show')
            # Save data into database
            pass
    else:
        form = EmployeeForm()
    return render(request, "index.html", {'form': form})

def show(request):
    employees = Employee.objects.all()
    return render(request, "show.html", {"employee": employees})