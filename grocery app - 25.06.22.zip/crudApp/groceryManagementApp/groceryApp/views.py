from django.shortcuts import render, redirect
from groceryApp.forms import GroceryForm
from groceryApp.models import Grocery

# Create your views here.
def createGrocery(request):
    if request.method == "POST":
        form = GroceryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/show')
            pass
    else:
        form = GroceryForm()
    return render(request, "index.html", {'form': form})

def show(request):
    groceries = Grocery.objects.all()
    return render(request, "show.html", {"groceries":groceries})

def edit(request, id):
    groceryApp = Grocery.objects.get(productName = id)
    return render(request, "edit.html", {"groceries":groceries})

def update(request, id):
    groceryApp = Grocery.objects.get(productName = id)
    form = GroceryForm(request.POST, instance = groceries)
    if form.is_valid():
        form.save()
        return redirect('/show')
    return render(request, "edit.html", {"groceries": groceries})

def delete(request, id):
    groceryApp = Grocery.objects.get(productName = id)
    groceryApp.delete()
    return redirect('/show')