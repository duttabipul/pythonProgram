from django.db import models

# Create your models here.
class Grocery(models.Model):
    productName = models.CharField(max_length = 200)
    perUnit = models.CharField(max_length = 200)
    quantity = models.CharField(max_length = 200)
    totalPrice = models.CharField(max_length = 200)

    class Meta:
        db_table = "grocery"