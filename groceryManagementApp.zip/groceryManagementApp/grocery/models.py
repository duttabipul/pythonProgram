from django.db import models


# Create your models here.
class Shop(models.Model):
    itemName = models.CharField(max_length = 200)
    unitPrice = models.CharField(max_length = 50)
    totalQty = models.CharField(max_length = 50)
    totalPrice = models.CharField(max_length = 200)


class Meta:
    db_table = "grocery"