from django import forms
from grocery.models import Shop

class GroceryForm(forms.ModelForm):
    class Meta:
        model = Shop
        fields = "__all__"