from django.shortcuts import render, redirect
from grocery.forms import GroceryForm
from grocery.models import Shop

# Create a Grocery:

def createItem(request):
    if request.method == "POST":
        form = GroceryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/show')
            pass
    else:
        form = GroceryForm()
    return render(request, "index.html", {'form':form})

def show(request):
    groceries = Shop.objects.all()
    #grocery.totalPrice = groceries.unitPrice * totalQty
    return render(request, "show.html", {"grocery" : groceries})

def edit(request, id):
    grocery = Shop.objects.get(id = id)
    return render(request, "edit.html", {"grocery" : grocery})

def update(request, id):
    grocery = Shop.objects.get(id = id)
    form = GroceryForm(request.POST, instance = grocery)
    if form.is_valid():
        form.save()
        return redirect('/show')
    return render(request, "edit.html", {"grocery" : grocery})

def delete(request, id):
    grocery = Shop.objects.get(id = id)
    grocery.delete()
    return redirect('/show')