from django.apps import AppConfig


class GroceryitemappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'grocery'
